画像 background.png は以下のサイトから持ってきたフリー画像。
https://www.ac-illust.com/main/detail.php?id=2614390&word=0%E3%81%A81%E3%81%AE%E3%83%87%E3%82%B8%E3%82%BF%E3%83%AB%E3%83%97%E3%83%AD%E3%82%B0%E3%83%A9%E3%83%9F%E3%83%B3%E3%82%B0%E9%9D%92%E3%81%84%E5%85%89%E8%83%8C%E6%99%AF&data_type=&from_order_history=&downloader_register=success
